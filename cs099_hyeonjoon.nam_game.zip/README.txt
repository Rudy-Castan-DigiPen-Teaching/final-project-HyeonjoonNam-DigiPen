/*Hyeonjoon_nam
  Final Project
  CS099
  Spring 2020 */
  
/* 
You can shoot Zombies by clicking your mouse. If you click mouse, bullets will come out and the zombie will come out also. If you hit zombie by bullets, the zombie will disappeared, and the score will increased. If zombies come near to the barricade, the barricade life will decreased, and if the barricade life go down to zero, GAME OVER.
*/