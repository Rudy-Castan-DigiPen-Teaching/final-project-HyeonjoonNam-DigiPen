/*Hyeonjoon_nam
  Final Project
  CS099
  Spring 2020 */

class Ending
{
  constructor(){
    
  }
  Draw(){
    push();
    textAlign(CENTER, CENTER);
    textSize(30);
    text("You survived.\n Congratulations!", width/2, height/2);
    pop();
  }
}